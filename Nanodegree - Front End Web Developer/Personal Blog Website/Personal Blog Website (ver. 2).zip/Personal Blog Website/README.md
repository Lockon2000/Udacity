# Personal Blog Website Project

## Usage
- Copy the folder with ALL its contents somewhere on disk.
- Open index.html

## Remaks
- This project uses SCSS and not plain CSS.
- All code in this project was produced by me from scratch, except for one part (image frames in posts) where I was inspired
by some code on the internet and then I modified it to accomodate for my purposes.
- The imgaes and patters are license free from these pages (subtle patterns, toptal.com | pixabay.com)
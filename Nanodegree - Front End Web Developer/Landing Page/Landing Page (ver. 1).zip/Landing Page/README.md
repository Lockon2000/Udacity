# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

Just load the index.html in a browser and everything will be set.
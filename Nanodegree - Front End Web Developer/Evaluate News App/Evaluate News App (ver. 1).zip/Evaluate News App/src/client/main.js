import { handleSubmit } from './js/formHandler'


import './styles/base.scss';
import './styles/header.scss';
import './styles/main.scss';
import './styles/footer.scss';


export {
    handleSubmit
};
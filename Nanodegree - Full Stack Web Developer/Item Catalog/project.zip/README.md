# How to operate the Website

1. run "python database_setup.py"
2. run "python lotsofitems.py"
3. run "python main.py"
4. go to localhost:8000

* you should have python 2.7
* you should have all dependencies required by the program